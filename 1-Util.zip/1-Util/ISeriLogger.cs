﻿using Serilog.Events;

namespace _1_Util
{
    public interface ISeriLogger
    {
        string RootProperty { get; }
        void Write<T>(LogEventLevel level, string messageTemplate, T propertyValue);
    }
}