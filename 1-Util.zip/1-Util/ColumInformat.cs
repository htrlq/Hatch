﻿using System;

namespace _1_Util
{
    public class ColumInformat
    {
        public Type DataType { get; set; }
        public string Property { get; set; }
    }
}
