﻿using Microsoft.Extensions.Options;
using Serilog;
using Serilog.Context;
using Serilog.Core.Enrichers;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using System;
using System.Data;
using Serilog.Core;

namespace _1_Util
{

    public class SeriLogger: ISeriLogger
    {
        public static readonly LoggerConfiguration Instance = new LoggerConfiguration();

        private LoggerBuild LoggerBuild { get; }
        private TableBuild TableBuild { get; }
        private SeriLoggerConfigure Options { get; }

        public SeriLogger(IOptions<SeriLoggerConfigure> options, TableBuild build, LoggerBuild loggerBuild)
        {
            TableBuild = build;
            LoggerBuild = loggerBuild;
            Options = options.Value;
        }

        public virtual string RootProperty => "SourceProperty";

        public void Write<T>(LogEventLevel level, string messageTemplate, T propertyValue)
        {
            var type = typeof(T);
            Logger logger;

            if (!TableBuild.ContainsKey(type))
            {
                var addNewTable = TableBuild.Add(type);

                if (!addNewTable)
                    throw new TypeInitializationException(typeof(T).FullName, new Exception("Add New Table Error"));

                var columnOptions = new ColumnOptions()
                {
                    AdditionalDataColumns = TableBuild[type].ConvertAll(item => new DataColumn()
                        { DataType = item.DataType, ColumnName = item.Property })
                };

                columnOptions.Store.Add(StandardColumn.LogEvent);

                if (Options.IsSeq)
                {
                    logger = Instance?
                        .MinimumLevel.Verbose()
                        .Enrich.WithProperty(RootProperty, null)
                        .Enrich.FromLogContext()
                        .WriteTo.Seq(Options.SeqUrl)
                        .CreateLogger();
                }
                else
                {
                    logger = Instance?
                        .MinimumLevel.Verbose()
                        .Enrich.WithProperty(RootProperty, null)
                        .Enrich.FromLogContext()
                        .WriteTo.MSSqlServer(connectionString: Options.ConnectString, tableName: type.Name, restrictedToMinimumLevel: LogEventLevel.Debug, formatProvider: null, autoCreateSqlTable: true, columnOptions: columnOptions)
                        .CreateLogger();
                }

                var addNewLogger = LoggerBuild.Add(type, logger);

                if (!addNewLogger)
                    throw new TypeInitializationException(typeof(T).FullName, new Exception("Add New Logger Error"));
            }
            else
            {
                logger = LoggerBuild[type];
            }

            var list = TableBuild[type];

            var entity = list.ConvertAll(item =>
            {
                var propertyInfo = type.GetProperty(item.Property);
                var value = propertyInfo?.GetValue(propertyValue);
                return new PropertyEnricher(item.Property, value);
            });

            using (LogContext.Push(entity.ToArray()))
                logger?.Write(level, messageTemplate, propertyValue);
        }
    }
}
